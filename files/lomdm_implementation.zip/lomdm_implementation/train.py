"""
Training script for LoMDM.

This script trains the Learnable-Order Masked Diffusion Model following
Algorithm 1 from the paper.

Usage:
    python train.py --dataset lm1b --batch_size 256 --max_steps 1000000
    python train.py --dataset openwebtext --batch_size 32 --max_steps 1000000
"""

import os
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from transformers import AutoTokenizer
from datasets import load_dataset
from tqdm import tqdm
import wandb
from typing import Optional, Dict

from lomdm import LoMDM, LoMDMConfig, TrainingConfig
from lomdm.utils import (
    set_seed,
    get_cosine_schedule_with_warmup,
    AverageMeter,
    EMA,
    save_checkpoint,
    load_checkpoint,
    count_parameters,
    get_grad_norm,
    GradScaler,
    compute_correlation,
)
from lomdm.diffusion import sample_forward_process


def parse_args():
    parser = argparse.ArgumentParser(description="Train LoMDM")
    
    # Data
    parser.add_argument("--dataset", type=str, default="lm1b",
                        choices=["lm1b", "openwebtext", "text8"])
    parser.add_argument("--tokenizer", type=str, default="bert-base-uncased")
    parser.add_argument("--max_length", type=int, default=128)
    
    # Model
    parser.add_argument("--hidden_size", type=int, default=768)
    parser.add_argument("--num_layers", type=int, default=12)
    parser.add_argument("--num_heads", type=int, default=12)
    parser.add_argument("--c1", type=float, default=0.7)
    parser.add_argument("--c2", type=float, default=0.65)
    
    # Training
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--learning_rate", type=float, default=3e-4)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--max_steps", type=int, default=1000000)
    parser.add_argument("--warmup_steps", type=int, default=10000)
    parser.add_argument("--grad_clip", type=float, default=1.0)
    
    # Mixed precision
    parser.add_argument("--fp16", action="store_true")
    parser.add_argument("--bf16", action="store_true")
    
    # Logging
    parser.add_argument("--log_every", type=int, default=100)
    parser.add_argument("--eval_every", type=int, default=5000)
    parser.add_argument("--save_every", type=int, default=10000)
    parser.add_argument("--output_dir", type=str, default="outputs")
    
    # Wandb
    parser.add_argument("--wandb_project", type=str, default="lomdm")
    parser.add_argument("--wandb_run_name", type=str, default=None)
    parser.add_argument("--no_wandb", action="store_true")
    
    # Misc
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--resume", type=str, default=None)
    
    # EMA
    parser.add_argument("--use_ema", action="store_true")
    parser.add_argument("--ema_decay", type=float, default=0.9999)
    
    return parser.parse_args()


def get_dataset(args, tokenizer):
    """Load and preprocess dataset."""
    
    if args.dataset == "lm1b":
        dataset = load_dataset("lm1b", split="train")
        text_column = "text"
    elif args.dataset == "openwebtext":
        dataset = load_dataset("openwebtext", split="train")
        text_column = "text"
    elif args.dataset == "text8":
        # Text8 requires special handling
        dataset = load_dataset("text8", split="train")
        text_column = "text"
    else:
        raise ValueError(f"Unknown dataset: {args.dataset}")
    
    def tokenize_function(examples):
        # Tokenize and truncate/pad to max_length
        tokens = tokenizer(
            examples[text_column],
            truncation=True,
            padding="max_length",
            max_length=args.max_length,
            return_tensors="pt",
        )
        return {"input_ids": tokens["input_ids"]}
    
    # Process dataset
    tokenized_dataset = dataset.map(
        tokenize_function,
        batched=True,
        remove_columns=dataset.column_names,
        num_proc=4,
    )
    
    tokenized_dataset.set_format(type="torch", columns=["input_ids"])
    
    return tokenized_dataset


def collate_fn(batch):
    """Collate function for DataLoader."""
    input_ids = torch.stack([item["input_ids"] for item in batch])
    return {"input_ids": input_ids}


def train_step(
    model: LoMDM,
    batch: Dict[str, torch.Tensor],
    optimizer: torch.optim.Optimizer,
    scaler: GradScaler,
    grad_clip: float,
    device: torch.device,
) -> Dict[str, float]:
    """Perform one training step."""
    
    model.train()
    optimizer.zero_grad()
    
    # Get input
    x = batch["input_ids"].to(device)
    B, L = x.shape
    
    # Sample time uniformly
    t = torch.rand(B, device=device)
    
    # Forward pass with mixed precision
    with torch.cuda.amp.autocast(enabled=scaler.enabled):
        loss, loss_dict = model.training_step(x, t)
    
    # Backward pass
    scaler.scale(loss).backward()
    
    # Gradient clipping
    if grad_clip > 0:
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
    
    # Optimizer step
    scaler.step(optimizer)
    scaler.update()
    
    # Get grad norm for logging
    grad_norm = get_grad_norm(model)
    
    # Return metrics
    metrics = {
        "loss": loss.item(),
        "main_loss": loss_dict["main_loss"].item(),
        "velocity_loss": loss_dict["velocity_loss"].item(),
        "rloo_loss": loss_dict["rloo_loss"].item(),
        "mask_ratio": loss_dict["mask_ratio"].item(),
        "grad_norm": grad_norm,
    }
    
    return metrics


@torch.no_grad()
def evaluate(
    model: LoMDM,
    eval_dataloader: DataLoader,
    device: torch.device,
    num_batches: int = 100,
) -> Dict[str, float]:
    """Evaluate model on validation set."""
    
    model.eval()
    
    total_loss = AverageMeter()
    main_loss = AverageMeter()
    velocity_loss = AverageMeter()
    
    # Track correlation between velocity and confidence
    all_velocities = []
    all_confidences = []
    
    for i, batch in enumerate(eval_dataloader):
        if i >= num_batches:
            break
        
        x = batch["input_ids"].to(device)
        B, L = x.shape
        
        # Sample time
        t = torch.rand(B, device=device)
        
        # Get features and scheduler values
        clean_features = model.get_backbone_features(x, stop_gradient=True)
        alpha_phi, velocity_phi = model.forward_scheduler(clean_features, t)
        
        # Sample masked sequence
        z_t, mask = sample_forward_process(x, alpha_phi, model.mask_token_id)
        
        # Get predictions
        logits = model(z_t)
        probs = F.softmax(logits, dim=-1)
        
        # Get confidence (probability of correct token)
        confidence = torch.gather(probs, -1, x.unsqueeze(-1)).squeeze(-1)
        
        # Get reverse scheduler
        features_z = model.get_backbone_features(z_t, stop_gradient=True)
        _, velocity_psi = model.reverse_scheduler(features_z, t)
        
        # Compute losses
        from lomdm.losses import compute_lomdm_loss
        loss, loss_dict = compute_lomdm_loss(
            logits, x, velocity_phi, velocity_psi, mask
        )
        
        total_loss.update(loss.item(), B)
        main_loss.update(loss_dict["main_loss"].item(), B)
        velocity_loss.update(loss_dict["velocity_loss"].item(), B)
        
        # Store for correlation
        all_velocities.append(velocity_phi[mask].cpu())
        all_confidences.append(confidence[mask].cpu())
    
    # Compute correlation
    all_velocities = torch.cat(all_velocities)
    all_confidences = torch.cat(all_confidences)
    correlation = compute_correlation(all_velocities, all_confidences)
    
    return {
        "eval_loss": total_loss.avg,
        "eval_main_loss": main_loss.avg,
        "eval_velocity_loss": velocity_loss.avg,
        "velocity_confidence_corr": correlation,
    }


def main():
    args = parse_args()
    
    # Set seed
    set_seed(args.seed)
    
    # Device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    # Initialize wandb
    if not args.no_wandb:
        wandb.init(
            project=args.wandb_project,
            name=args.wandb_run_name or f"lomdm-{args.dataset}",
            config=vars(args),
        )
    
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer)
    
    # Add mask token if not present
    if tokenizer.mask_token is None:
        tokenizer.add_special_tokens({"mask_token": "[MASK]"})
    
    mask_token_id = tokenizer.mask_token_id
    vocab_size = len(tokenizer)
    
    print(f"Vocab size: {vocab_size}, Mask token ID: {mask_token_id}")
    
    # Create config
    config = LoMDMConfig(
        vocab_size=vocab_size,
        max_seq_length=args.max_length,
        mask_token_id=mask_token_id,
        hidden_size=args.hidden_size,
        num_hidden_layers=args.num_layers,
        num_attention_heads=args.num_heads,
        c1=args.c1,
        c2=args.c2,
    )
    
    # Create model
    model = LoMDM(config).to(device)
    
    print(f"Model parameters: {count_parameters(model):,}")
    param_breakdown = model.get_num_params()
    print(f"  Backbone: {param_breakdown['backbone']:,}")
    print(f"  Forward scheduler: {param_breakdown['forward_scheduler']:,}")
    print(f"  Reverse scheduler: {param_breakdown['reverse_scheduler']:,}")
    
    # Create optimizer
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
        betas=(0.9, 0.98),
    )
    
    # Create scheduler
    scheduler = get_cosine_schedule_with_warmup(
        optimizer,
        num_warmup_steps=args.warmup_steps,
        num_training_steps=args.max_steps,
    )
    
    # Create EMA if requested
    ema = EMA(model, decay=args.ema_decay, device=device) if args.use_ema else None
    
    # Create gradient scaler
    scaler = GradScaler(enabled=args.fp16 and torch.cuda.is_available())
    
    # Load dataset
    print("Loading dataset...")
    dataset = get_dataset(args, tokenizer)
    
    train_dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        collate_fn=collate_fn,
        pin_memory=True,
    )
    
    # For evaluation, use a subset
    eval_dataloader = DataLoader(
        dataset.select(range(min(10000, len(dataset)))),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        collate_fn=collate_fn,
    )
    
    # Resume from checkpoint
    start_step = 0
    if args.resume:
        print(f"Resuming from {args.resume}")
        start_step, _ = load_checkpoint(
            args.resume, model, optimizer, scheduler, ema, device
        )
    
    # Training loop
    print("Starting training...")
    step = start_step
    
    metrics_avg = {
        "loss": AverageMeter(),
        "main_loss": AverageMeter(),
        "velocity_loss": AverageMeter(),
        "rloo_loss": AverageMeter(),
    }
    
    pbar = tqdm(total=args.max_steps - start_step, initial=start_step)
    
    while step < args.max_steps:
        for batch in train_dataloader:
            if step >= args.max_steps:
                break
            
            # Train step
            metrics = train_step(
                model, batch, optimizer, scaler, args.grad_clip, device
            )
            
            # Update scheduler
            scheduler.step()
            
            # Update EMA
            if ema is not None:
                ema.update()
            
            # Update metrics
            for k, v in metrics.items():
                if k in metrics_avg:
                    metrics_avg[k].update(v)
            
            step += 1
            pbar.update(1)
            
            # Logging
            if step % args.log_every == 0:
                log_metrics = {
                    "loss": metrics_avg["loss"].avg,
                    "main_loss": metrics_avg["main_loss"].avg,
                    "velocity_loss": metrics_avg["velocity_loss"].avg,
                    "rloo_loss": metrics_avg["rloo_loss"].avg,
                    "lr": scheduler.get_last_lr()[0],
                    "grad_norm": metrics["grad_norm"],
                }
                
                pbar.set_postfix(loss=f'{log_metrics["loss"]:.4f}')
                
                if not args.no_wandb:
                    wandb.log({"train/" + k: v for k, v in log_metrics.items()}, step=step)
                
                # Reset meters
                for meter in metrics_avg.values():
                    meter.reset()
            
            # Evaluation
            if step % args.eval_every == 0:
                print(f"\nEvaluating at step {step}...")
                
                if ema is not None:
                    ema.apply_shadow()
                
                eval_metrics = evaluate(model, eval_dataloader, device)
                
                if ema is not None:
                    ema.restore()
                
                print(f"Eval loss: {eval_metrics['eval_loss']:.4f}")
                print(f"Velocity-confidence correlation: {eval_metrics['velocity_confidence_corr']:.4f}")
                
                if not args.no_wandb:
                    wandb.log({"eval/" + k: v for k, v in eval_metrics.items()}, step=step)
            
            # Save checkpoint
            if step % args.save_every == 0:
                save_path = os.path.join(args.output_dir, f"checkpoint-{step}.pt")
                print(f"\nSaving checkpoint to {save_path}")
                save_checkpoint(
                    model, optimizer, scheduler, step,
                    metrics_avg["loss"].avg, save_path, ema
                )
    
    pbar.close()
    
    # Final save
    save_path = os.path.join(args.output_dir, "checkpoint-final.pt")
    save_checkpoint(model, optimizer, scheduler, step, 0, save_path, ema)
    
    print("Training complete!")
    
    if not args.no_wandb:
        wandb.finish()


if __name__ == "__main__":
    main()
