"""
Loss computations for LoMDM.

Implements the NELBO objective from Equation (3) in the paper:
L_LoMDM = ∫ E_qαφ [ Σ_i <z_t^(i), m> * (L_main^(i) + L_velocity^(i)) ] dt

Where:
- L_main = -A_φ^(i) * log<x_θ^(i)(z_t, t), x^(i)>
- L_velocity = A_φ^(i) * (log A_φ^(i) - log Â_ψ^(i)) - (A_φ^(i) - Â_ψ^(i))

Also implements the RLOO (Leave-One-Out) gradient estimator from Equation (8).
"""

import torch
import torch.nn.functional as F
from typing import Tuple, Dict


def compute_main_loss(
    logits: torch.Tensor,
    targets: torch.Tensor,
    velocity_phi: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    """
    Compute the main reconstruction loss L_main for masked positions.
    
    L_main^(i) = -A_φ^(i) * log<x_θ^(i)(z_t, t), x^(i)>
    
    This is weighted cross-entropy where the weight is the velocity A_φ.
    Tokens with higher velocity (earlier generation order) contribute more to the loss.
    
    Args:
        logits: Model output logits, shape (B, L, V)
        targets: Ground truth token IDs, shape (B, L)
        velocity_phi: Forward scheduler velocity A_φ, shape (B, L)
        mask: Boolean mask indicating masked positions, shape (B, L)
        
    Returns:
        loss: Scalar loss value (mean over batch)
    """
    # Cross-entropy loss per position
    log_probs = F.log_softmax(logits, dim=-1)  # (B, L, V)
    
    # Gather log probs for target tokens
    target_log_probs = torch.gather(
        log_probs, 
        dim=-1, 
        index=targets.unsqueeze(-1)
    ).squeeze(-1)  # (B, L)
    
    # Weight by velocity and mask
    # Only compute loss on masked positions (where mask is True)
    weighted_loss = -velocity_phi * target_log_probs * mask.float()  # (B, L)
    
    # Sum over positions, mean over batch
    # Normalize by number of masked tokens
    num_masked = mask.float().sum(dim=-1).clamp(min=1)  # (B,)
    loss_per_sample = weighted_loss.sum(dim=-1) / num_masked
    
    return loss_per_sample.mean()


def compute_velocity_loss(
    velocity_phi: torch.Tensor,
    velocity_psi: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    """
    Compute the velocity matching loss L_velocity for masked positions.
    
    L_velocity^(i) = A_φ^(i) * (log A_φ^(i) - log Â_ψ^(i)) - (A_φ^(i) - Â_ψ^(i))
    
    This is essentially a KL-divergence-like term that encourages the reverse
    scheduler to match the forward scheduler's velocity.
    
    Note: This simplifies to a form related to KL(q || p) for the velocities.
    When A_φ = Â_ψ, this loss is 0.
    
    Args:
        velocity_phi: Forward scheduler velocity A_φ, shape (B, L)
        velocity_psi: Reverse scheduler velocity Â_ψ, shape (B, L)
        mask: Boolean mask indicating masked positions, shape (B, L)
        
    Returns:
        loss: Scalar loss value (mean over batch)
    """
    # Clamp velocities for numerical stability
    velocity_phi_clamped = velocity_phi.clamp(min=1e-6)
    velocity_psi_clamped = velocity_psi.clamp(min=1e-6)
    
    # Compute L_velocity = A_φ * (log A_φ - log Â_ψ) - (A_φ - Â_ψ)
    log_ratio = torch.log(velocity_phi_clamped) - torch.log(velocity_psi_clamped)
    velocity_diff = velocity_phi - velocity_psi
    
    loss_per_position = velocity_phi * log_ratio - velocity_diff  # (B, L)
    
    # Only compute loss on masked positions
    masked_loss = loss_per_position * mask.float()
    
    # Sum over positions, mean over batch
    num_masked = mask.float().sum(dim=-1).clamp(min=1)
    loss_per_sample = masked_loss.sum(dim=-1) / num_masked
    
    return loss_per_sample.mean()


def compute_lomdm_loss(
    logits: torch.Tensor,
    targets: torch.Tensor,
    velocity_phi: torch.Tensor,
    velocity_psi: torch.Tensor,
    mask: torch.Tensor,
) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """
    Compute the full LoMDM loss: L_main + L_velocity.
    
    Args:
        logits: Model output logits, shape (B, L, V)
        targets: Ground truth token IDs, shape (B, L)
        velocity_phi: Forward scheduler velocity A_φ, shape (B, L)
        velocity_psi: Reverse scheduler velocity Â_ψ, shape (B, L)
        mask: Boolean mask indicating masked positions, shape (B, L)
        
    Returns:
        total_loss: Total loss (L_main + L_velocity)
        loss_dict: Dictionary with individual loss components
    """
    main_loss = compute_main_loss(logits, targets, velocity_phi, mask)
    velocity_loss = compute_velocity_loss(velocity_phi, velocity_psi, mask)
    
    total_loss = main_loss + velocity_loss
    
    loss_dict = {
        "loss": total_loss,
        "main_loss": main_loss,
        "velocity_loss": velocity_loss,
    }
    
    return total_loss, loss_dict


def compute_rloo_loss(
    z1_t: torch.Tensor,
    z2_t: torch.Tensor,
    alpha_phi: torch.Tensor,
    mask_token_id: int,
    loss_z1: torch.Tensor,
    loss_z2: torch.Tensor,
) -> torch.Tensor:
    """
    Compute the RLOO (Reinforce Leave-One-Out) gradient estimator loss.
    
    From Equation (8) in the paper:
    L_rloo = 1/2 * log(q_αφ(z1_t|x) / q_αφ(z2_t|x)) * Sgd(L_z1 - L_z2)
    
    This provides a low-variance gradient estimator for the scheduler φ
    through the discrete sampling operation.
    
    Args:
        z1_t: First sampled masked sequence, shape (B, L)
        z2_t: Second sampled masked sequence, shape (B, L)
        alpha_phi: Forward scheduler α values, shape (B, L)
        mask_token_id: Token ID for [MASK]
        loss_z1: Loss computed on z1_t (stop-gradiented in computation)
        loss_z2: Loss computed on z2_t (stop-gradiented in computation)
        
    Returns:
        rloo_loss: RLOO loss for gradient estimation
    """
    from .diffusion import compute_forward_log_prob
    
    # We need a clean x to compute log probs, but in practice we use the ratio
    # which cancels out the shared terms
    
    # Compute log probabilities
    # For the ratio, we just need the difference in log probs
    # log q(z1|x) - log q(z2|x) can be computed position-wise
    
    # Positions that differ between z1 and z2
    z1_masked = (z1_t == mask_token_id)
    z2_masked = (z2_t == mask_token_id)
    
    # Clamp alpha for numerical stability
    alpha_clamped = alpha_phi.clamp(min=1e-6, max=1.0 - 1e-6)
    
    # Log prob for each masking state
    log_prob_unmasked = torch.log(alpha_clamped)
    log_prob_masked = torch.log(1.0 - alpha_clamped)
    
    # Compute log q(z1|x)
    log_q_z1 = torch.where(z1_masked, log_prob_masked, log_prob_unmasked)
    log_q_z1 = log_q_z1.sum(dim=-1)  # (B,)
    
    # Compute log q(z2|x)
    log_q_z2 = torch.where(z2_masked, log_prob_masked, log_prob_unmasked)
    log_q_z2 = log_q_z2.sum(dim=-1)  # (B,)
    
    # Log ratio
    log_ratio = log_q_z1 - log_q_z2  # (B,)
    
    # Loss difference (stop-gradiented)
    loss_diff = loss_z1.detach() - loss_z2.detach()  # (B,) or scalar
    
    # Handle scalar vs batch loss
    if loss_diff.dim() == 0:
        loss_diff = loss_diff.expand_as(log_ratio)
    
    # RLOO loss
    rloo_loss = 0.5 * log_ratio * loss_diff
    
    return rloo_loss.mean()


def compute_full_training_loss(
    model,
    x: torch.Tensor,
    t: torch.Tensor,
    mask_token_id: int,
) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """
    Compute the full LoMDM training loss with two-sample estimator.
    
    This follows Algorithm 1 in the paper:
    1. Get backbone features from clean x (with stop-gradient)
    2. Compute forward scheduler α_φ(x, t) and A_φ(x, t)
    3. Sample two masked sequences z1_t, z2_t ~ q_αφ(·|x)
    4. For each z_t:
       - Get model predictions x_θ(z_t, t)
       - Get backbone features for z_t (with stop-gradient)
       - Compute reverse scheduler Â_ψ(z_t, t)
       - Compute L_main + L_velocity
    5. Compute RLOO loss for gradient estimation
    6. Return average loss + RLOO loss
    
    Args:
        model: LoMDM model
        x: Clean token sequence, shape (B, L)
        t: Time values, shape (B,)
        mask_token_id: Token ID for [MASK]
        
    Returns:
        total_loss: Combined loss for gradient descent
        loss_dict: Dictionary with all loss components
    """
    from .diffusion import sample_forward_process
    
    B, L = x.shape
    
    # Step 1: Get backbone features from clean x (with stop-gradient)
    with torch.no_grad():
        clean_features = model.backbone.get_features(x)
    
    # Step 2: Compute forward scheduler
    alpha_phi, velocity_phi = model.forward_scheduler(clean_features, t)
    
    # Step 3: Sample two masked sequences
    z1_t, mask1 = sample_forward_process(x, alpha_phi, mask_token_id)
    z2_t, mask2 = sample_forward_process(x, alpha_phi, mask_token_id)
    
    # Step 4a: Process z1_t
    logits1, _ = model.backbone(z1_t, t, return_hidden_states=True)
    with torch.no_grad():
        features_z1 = model.backbone.get_features(z1_t)
    _, velocity_psi1 = model.reverse_scheduler(features_z1, t)
    loss1, loss_dict1 = compute_lomdm_loss(logits1, x, velocity_phi, velocity_psi1, mask1)
    
    # Step 4b: Process z2_t
    logits2, _ = model.backbone(z2_t, t, return_hidden_states=True)
    with torch.no_grad():
        features_z2 = model.backbone.get_features(z2_t)
    _, velocity_psi2 = model.reverse_scheduler(features_z2, t)
    loss2, loss_dict2 = compute_lomdm_loss(logits2, x, velocity_phi, velocity_psi2, mask2)
    
    # Step 5: Compute RLOO loss
    rloo_loss = compute_rloo_loss(z1_t, z2_t, alpha_phi, mask_token_id, loss1, loss2)
    
    # Step 6: Combine losses
    avg_loss = 0.5 * (loss1 + loss2)
    total_loss = avg_loss + rloo_loss
    
    # Aggregate loss dict
    loss_dict = {
        "total_loss": total_loss,
        "avg_loss": avg_loss,
        "rloo_loss": rloo_loss,
        "main_loss": 0.5 * (loss_dict1["main_loss"] + loss_dict2["main_loss"]),
        "velocity_loss": 0.5 * (loss_dict1["velocity_loss"] + loss_dict2["velocity_loss"]),
        "mask_ratio_z1": mask1.float().mean(),
        "mask_ratio_z2": mask2.float().mean(),
    }
    
    return total_loss, loss_dict


def compute_mdlm_baseline_loss(
    logits: torch.Tensor,
    targets: torch.Tensor,
    t: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    """
    Compute the standard MDLM loss (without learnable scheduler) for comparison.
    
    L_MDLM = (α'_t / (1 - α_t)) * Σ_i CE(x_θ^(i), x^(i)) * mask^(i)
    
    With linear schedule α_t = 1 - t: α'_t / (1 - α_t) = 1/t
    
    Args:
        logits: Model output logits, shape (B, L, V)
        targets: Ground truth token IDs, shape (B, L)
        t: Time values, shape (B,) or (B, 1)
        mask: Boolean mask indicating masked positions, shape (B, L)
        
    Returns:
        loss: Scalar loss value
    """
    if t.dim() == 1:
        t = t.unsqueeze(-1)
    
    # Cross-entropy loss per position
    ce_loss = F.cross_entropy(
        logits.view(-1, logits.size(-1)),
        targets.view(-1),
        reduction='none'
    ).view_as(targets)  # (B, L)
    
    # MDLM weight: 1/t for linear schedule
    weight = 1.0 / t.clamp(min=1e-6)  # (B, 1)
    
    # Apply weight and mask
    weighted_loss = weight * ce_loss * mask.float()
    
    # Sum over positions, mean over batch
    num_masked = mask.float().sum(dim=-1).clamp(min=1)
    loss_per_sample = weighted_loss.sum(dim=-1) / num_masked
    
    return loss_per_sample.mean()
