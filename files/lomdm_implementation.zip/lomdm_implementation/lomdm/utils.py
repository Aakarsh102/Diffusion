"""
Utility functions for LoMDM training and evaluation.
"""

import torch
import torch.nn as nn
import numpy as np
import random
import math
from typing import Optional, Dict, Any, Tuple
import os


def set_seed(seed: int):
    """Set random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_linear_schedule_with_warmup(
    optimizer,
    num_warmup_steps: int,
    num_training_steps: int,
    last_epoch: int = -1,
):
    """
    Create a schedule with linear warmup and linear decay.
    
    Args:
        optimizer: PyTorch optimizer
        num_warmup_steps: Number of warmup steps
        num_training_steps: Total number of training steps
        last_epoch: Last epoch (for resuming)
        
    Returns:
        LambdaLR scheduler
    """
    def lr_lambda(current_step: int):
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1, num_warmup_steps))
        return max(
            0.0,
            float(num_training_steps - current_step) / 
            float(max(1, num_training_steps - num_warmup_steps))
        )
    
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda, last_epoch)


def get_cosine_schedule_with_warmup(
    optimizer,
    num_warmup_steps: int,
    num_training_steps: int,
    num_cycles: float = 0.5,
    last_epoch: int = -1,
):
    """
    Create a schedule with linear warmup and cosine decay.
    
    Args:
        optimizer: PyTorch optimizer
        num_warmup_steps: Number of warmup steps
        num_training_steps: Total number of training steps
        num_cycles: Number of cosine cycles (0.5 = decay to 0)
        last_epoch: Last epoch (for resuming)
        
    Returns:
        LambdaLR scheduler
    """
    def lr_lambda(current_step: int):
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1, num_warmup_steps))
        progress = float(current_step - num_warmup_steps) / float(
            max(1, num_training_steps - num_warmup_steps)
        )
        return max(0.0, 0.5 * (1.0 + math.cos(math.pi * float(num_cycles) * 2.0 * progress)))
    
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda, last_epoch)


class AverageMeter:
    """Computes and stores the average and current value."""
    
    def __init__(self):
        self.reset()
    
    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0
    
    def update(self, val: float, n: int = 1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


class EMA:
    """
    Exponential Moving Average for model parameters.
    
    Maintains a shadow copy of model parameters that is updated
    with exponential moving average during training.
    """
    
    def __init__(
        self,
        model: nn.Module,
        decay: float = 0.9999,
        device: Optional[torch.device] = None,
    ):
        self.model = model
        self.decay = decay
        self.device = device
        self.shadow = {}
        self.backup = {}
        
        for name, param in model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = param.data.clone().to(device or param.device)
    
    def update(self):
        """Update shadow parameters."""
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                new_average = (
                    self.decay * self.shadow[name] +
                    (1.0 - self.decay) * param.data
                )
                self.shadow[name] = new_average.clone()
    
    def apply_shadow(self):
        """Apply shadow parameters to model."""
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                self.backup[name] = param.data
                param.data = self.shadow[name]
    
    def restore(self):
        """Restore original parameters."""
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                param.data = self.backup[name]
        self.backup = {}
    
    def state_dict(self) -> Dict[str, torch.Tensor]:
        return self.shadow
    
    def load_state_dict(self, state_dict: Dict[str, torch.Tensor]):
        self.shadow = state_dict


def save_checkpoint(
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler,
    step: int,
    loss: float,
    path: str,
    ema: Optional[EMA] = None,
):
    """Save training checkpoint."""
    checkpoint = {
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "scheduler_state_dict": scheduler.state_dict() if scheduler else None,
        "step": step,
        "loss": loss,
    }
    if ema is not None:
        checkpoint["ema_state_dict"] = ema.state_dict()
    
    os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save(checkpoint, path)


def load_checkpoint(
    path: str,
    model: nn.Module,
    optimizer: Optional[torch.optim.Optimizer] = None,
    scheduler=None,
    ema: Optional[EMA] = None,
    device: Optional[torch.device] = None,
) -> Tuple[int, float]:
    """Load training checkpoint."""
    checkpoint = torch.load(path, map_location=device or "cpu")
    
    model.load_state_dict(checkpoint["model_state_dict"])
    
    if optimizer is not None and "optimizer_state_dict" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    
    if scheduler is not None and checkpoint.get("scheduler_state_dict"):
        scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
    
    if ema is not None and "ema_state_dict" in checkpoint:
        ema.load_state_dict(checkpoint["ema_state_dict"])
    
    return checkpoint.get("step", 0), checkpoint.get("loss", 0.0)


def count_parameters(model: nn.Module) -> int:
    """Count total trainable parameters."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def get_grad_norm(model: nn.Module) -> float:
    """Compute gradient norm for logging."""
    total_norm = 0.0
    for p in model.parameters():
        if p.grad is not None:
            param_norm = p.grad.data.norm(2)
            total_norm += param_norm.item() ** 2
    return total_norm ** 0.5


class GradScaler:
    """
    Simple gradient scaler for mixed precision training.
    
    Wraps torch.cuda.amp.GradScaler with a fallback for CPU.
    """
    
    def __init__(self, enabled: bool = True):
        self.enabled = enabled and torch.cuda.is_available()
        if self.enabled:
            self._scaler = torch.cuda.amp.GradScaler()
        else:
            self._scaler = None
    
    def scale(self, loss):
        if self.enabled:
            return self._scaler.scale(loss)
        return loss
    
    def step(self, optimizer):
        if self.enabled:
            self._scaler.step(optimizer)
        else:
            optimizer.step()
    
    def update(self):
        if self.enabled:
            self._scaler.update()
    
    def unscale_(self, optimizer):
        if self.enabled:
            self._scaler.unscale_(optimizer)


def compute_correlation(x: torch.Tensor, y: torch.Tensor) -> float:
    """
    Compute Pearson correlation coefficient between two tensors.
    
    Used to track correlation between velocity A and reconstruction confidence
    as mentioned in Section 5 of the paper.
    """
    x = x.flatten().float()
    y = y.flatten().float()
    
    # Remove NaN and Inf
    valid = torch.isfinite(x) & torch.isfinite(y)
    x = x[valid]
    y = y[valid]
    
    if len(x) < 2:
        return 0.0
    
    x_mean = x.mean()
    y_mean = y.mean()
    
    x_centered = x - x_mean
    y_centered = y - y_mean
    
    numerator = (x_centered * y_centered).sum()
    denominator = torch.sqrt((x_centered ** 2).sum() * (y_centered ** 2).sum())
    
    if denominator < 1e-8:
        return 0.0
    
    return (numerator / denominator).item()


def log_metrics(
    metrics: Dict[str, float],
    step: int,
    prefix: str = "",
    logger=None,
):
    """
    Log metrics to console and optional logger (e.g., wandb).
    
    Args:
        metrics: Dictionary of metric names to values
        step: Current training step
        prefix: Prefix for metric names (e.g., "train/")
        logger: Optional logger (e.g., wandb)
    """
    # Console logging
    metric_str = " | ".join([f"{k}: {v:.4f}" for k, v in metrics.items()])
    print(f"Step {step} | {metric_str}")
    
    # Optional logger
    if logger is not None:
        prefixed_metrics = {f"{prefix}{k}": v for k, v in metrics.items()}
        if hasattr(logger, "log"):
            logger.log(prefixed_metrics, step=step)


def top_k_top_p_filtering(
    logits: torch.Tensor,
    top_k: int = 0,
    top_p: float = 0.0,
    filter_value: float = float("-inf"),
) -> torch.Tensor:
    """
    Filter logits using top-k and/or nucleus (top-p) filtering.
    
    Args:
        logits: Logits distribution, shape (batch_size, vocab_size)
        top_k: Keep only top k tokens with highest probability (k > 0)
        top_p: Keep smallest set of tokens with cumulative probability >= p
        filter_value: Value to assign to filtered logits
        
    Returns:
        Filtered logits
    """
    if top_k > 0:
        # Remove all tokens with probability less than the last token of top-k
        indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
        logits[indices_to_remove] = filter_value
    
    if top_p > 0.0:
        sorted_logits, sorted_indices = torch.sort(logits, descending=True)
        cumulative_probs = torch.cumsum(torch.softmax(sorted_logits, dim=-1), dim=-1)
        
        # Remove tokens with cumulative probability above the threshold
        sorted_indices_to_remove = cumulative_probs > top_p
        # Shift the indices to the right to keep the first token above threshold
        sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
        sorted_indices_to_remove[..., 0] = 0
        
        # Scatter sorted tensors to original indexing
        indices_to_remove = sorted_indices_to_remove.scatter(
            -1, sorted_indices, sorted_indices_to_remove
        )
        logits[indices_to_remove] = filter_value
    
    return logits
