"""
Learnable-Order Masked Diffusion Model (LoMDM)

Implementation of "Unifying Masked Diffusion Models with Various Generation Orders and Beyond"
by Chunsan Hong, Sanghyun Lee, Jong Chul Ye (2026)

This implementation builds upon MDLM (Simple and Effective Masked Diffusion Language Models)
and introduces learnable position-dependent noise schedulers that enable context-aware 
generation ordering.

Key Components:
- OeMDM: Order-Expressive Masked Diffusion Model framework
- LoMDM: Learnable-Order extension with jointly trained schedulers
- Position-dependent schedulers α_φ(x,t) and α_ψ(z_t,t)
- RLOO gradient estimator for low-variance training
"""

from .model import LoMDM
from .backbone import DiffusionTransformer
from .scheduler import SchedulerNetwork, ForwardScheduler, ReverseScheduler
from .diffusion import (
    sample_forward_process,
    compute_alpha,
    compute_velocity,
    normalized_sigmoid,
)
from .losses import compute_lomdm_loss, compute_rloo_loss
from .sampling import LoMDMSampler
from .config import LoMDMConfig, TrainingConfig

__version__ = "1.0.0"
__all__ = [
    "LoMDM",
    "LoMDMConfig",
    "TrainingConfig",
    "DiffusionTransformer",
    "SchedulerNetwork",
    "ForwardScheduler", 
    "ReverseScheduler",
    "LoMDMSampler",
    "sample_forward_process",
    "compute_alpha",
    "compute_velocity",
    "normalized_sigmoid",
    "compute_lomdm_loss",
    "compute_rloo_loss",
]
