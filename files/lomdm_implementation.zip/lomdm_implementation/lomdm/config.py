"""
Configuration classes for LoMDM.
"""

from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class LoMDMConfig:
    """Configuration for the LoMDM model architecture."""
    
    # Vocabulary and sequence
    vocab_size: int = 30522  # BERT vocab size (can change for GPT-2: 50257)
    max_seq_length: int = 128  # LM1B uses 128, OWT uses 1024
    mask_token_id: int = 103  # [MASK] token id for BERT tokenizer
    
    # Backbone Transformer architecture
    hidden_size: int = 768
    num_hidden_layers: int = 12
    num_attention_heads: int = 12
    intermediate_size: int = 3072
    hidden_dropout_prob: float = 0.1
    attention_dropout_prob: float = 0.1
    
    # Scheduler network architecture
    scheduler_hidden_size: int = 768
    scheduler_num_heads: int = 12
    scheduler_mlp_ratio: float = 4.0
    
    # LoMDM specific hyperparameters (from Table 4 in paper)
    c1: float = 0.7  # Controls overall denoising velocity
    c2: float = 0.65  # Controls variance of generation order priority
    
    # c1 > c2 is required for valid scheduler (Proposition C.3)
    # Paper ablation shows (c1=0.7, c2=0.65) works best
    
    # Whether to use time conditioning in backbone (MDLM uses time-agnostic)
    time_conditioning: bool = False
    
    # Rotary position embeddings (RoPE)
    use_rotary_embeddings: bool = True
    rotary_dim: int = 64
    
    # Initialization
    initializer_range: float = 0.02


@dataclass
class TrainingConfig:
    """Configuration for training LoMDM."""
    
    # Training
    learning_rate: float = 3e-4
    weight_decay: float = 0.01
    adam_beta1: float = 0.9
    adam_beta2: float = 0.98
    adam_epsilon: float = 1e-8
    max_grad_norm: float = 1.0
    
    # Schedule
    warmup_steps: int = 10000
    max_steps: int = 1000000  # 1M steps
    
    # Batch size
    batch_size: int = 256  # Per GPU batch size
    global_batch_size: int = 512
    gradient_accumulation_steps: int = 1
    
    # Sampling during training
    num_diffusion_timesteps: int = 1000  # T for discrete sampling
    
    # Logging
    log_every_n_steps: int = 100
    eval_every_n_steps: int = 5000
    save_every_n_steps: int = 10000
    
    # Data
    dataset: str = "lm1b"  # "lm1b" or "openwebtext"
    tokenizer_name: str = "bert-base-uncased"  # or "gpt2"
    
    # Mixed precision
    use_fp16: bool = True
    use_bf16: bool = False
    
    # Distributed training
    num_gpus: int = 1
    
    # Random seed
    seed: int = 42


@dataclass 
class SamplingConfig:
    """Configuration for sampling from LoMDM."""
    
    # Number of sampling steps
    num_steps: int = 1000
    
    # Sampling strategy
    predictor: str = "ddpm_cache"  # "ddpm", "ddpm_cache", "analytic"
    
    # Temperature for sampling
    temperature: float = 1.0
    
    # Whether to use learned scheduler at inference
    use_learned_scheduler: bool = True
    
    # Semi-autoregressive generation
    semi_ar: bool = False
    stride_length: int = 512
    num_strides: int = 2
    
    # Generation
    num_samples: int = 64
    batch_size: int = 8
    max_length: int = 1024


def get_default_lm1b_config() -> tuple[LoMDMConfig, TrainingConfig]:
    """Get default configuration for LM1B dataset."""
    model_config = LoMDMConfig(
        vocab_size=30522,  # BERT vocab
        max_seq_length=128,
        mask_token_id=103,
        hidden_size=768,
        num_hidden_layers=12,
        num_attention_heads=12,
        c1=0.7,
        c2=0.65,
    )
    train_config = TrainingConfig(
        dataset="lm1b",
        tokenizer_name="bert-base-uncased",
        batch_size=256,
        global_batch_size=512,
    )
    return model_config, train_config


def get_default_owt_config() -> tuple[LoMDMConfig, TrainingConfig]:
    """Get default configuration for OpenWebText dataset."""
    model_config = LoMDMConfig(
        vocab_size=50257,  # GPT-2 vocab
        max_seq_length=1024,
        mask_token_id=50256,  # Will be added as extra token
        hidden_size=768,
        num_hidden_layers=12,
        num_attention_heads=12,
        c1=0.7,
        c2=0.65,
    )
    train_config = TrainingConfig(
        dataset="openwebtext",
        tokenizer_name="gpt2",
        batch_size=32,  # Smaller due to longer sequences
        global_batch_size=512,
    )
    return model_config, train_config
